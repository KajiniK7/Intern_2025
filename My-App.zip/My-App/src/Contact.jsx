
const Contact = () => {
    return (
        <h1>This is my contact page</h1>
    )
}

export default Contact