
const Gallery = () => {
    return (
        <h1>This is my Gallery Page</h1>
    )
}

export default Gallery