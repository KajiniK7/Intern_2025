
const About = (props)=>{

    return <center><div> 
            <h1>Hi I am {props.names}</h1><p >Iam a Computer science engineering student of 2nd year.Iam {props.age} years old</p>
            <input id="message"></input>
        </div></center>
}

export default About