
const Home = () => {
    return (
        <h1>This is a Home Page</h1>
    )
}

export default Home