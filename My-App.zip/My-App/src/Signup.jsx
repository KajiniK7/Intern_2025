const SignUp = ()=>{
    return <h1>Welcome to signUp page</h1>
}
export default SignUp